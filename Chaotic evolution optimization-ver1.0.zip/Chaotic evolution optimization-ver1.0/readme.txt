This is the Chaotic evolution optimization (CEO)
The main function is Test_CEO.
You are suggested to cite the following references if you are using the CEO.

1) Chaotic evolution optimization: A novel metaheuristic algorithm inspired by chaotic dynamics

Contact Information��
Dr. Yingchao Dong
Associate Professor
School of Energy Engineering,
Xinjiang Institute of Engineering,
Urumqi, Xinjiang, P.R. China 
830023
dycxju@163.com

The matlab codes are run under the Matlab 2020b. Please do not hesitate to contact me if you have any further questions.
